package com.example.intentpassingdata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivityMove extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_move);
    }
}
